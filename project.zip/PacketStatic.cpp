#include "PacketStatic.h"

void PacketStatic::saveheader(pcap_pkthdr *header){
    this->header = header;
    //cout << this->header->len << endl;
}

void PacketStatic::savemac(string smac, string dmac){
    this->smac = smac;
    this->dmac = dmac;
}

void PacketStatic::statistic(){
    if(whitemac.find(this->smac) == whitemac.end()){
         adrstatic[this->smac].tx += this->header->len;
    }
    if(whitemac.find(this->dmac) == whitemac.end()){
         adrstatic[this->dmac].rx += this->header->len;
    }
}
